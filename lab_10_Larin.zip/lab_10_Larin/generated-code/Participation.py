#!/usr/bin/python
# -*- coding: UTF-8 -*-
class Participation(object):
	def __init__(self):
		self._hours = None
		"""@AttributeType int"""

