#!/usr/bin/python
# -*- coding: UTF-8 -*-
import Employee

class AdministrativeEmployee(Employee):
	pass
